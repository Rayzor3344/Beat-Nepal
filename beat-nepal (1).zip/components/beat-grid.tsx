import BeatCard from "@/components/beat-card"

// Mock data for beats
const beats = [
  {
    id: "1",
    title: "Himalayan Trap",
    producer: "NepalBeats",
    description: "Hard-hitting trap beat with traditional Nepali instruments",
    audioUrl: "/beats/beat1.mp3",
    price: 29.99,
  },
  {
    id: "2",
    title: "Kathmandu Nights",
    producer: "MountainFlow",
    description: "Smooth R&B beat with atmospheric pads and crisp drums",
    audioUrl: "/beats/beat2.mp3",
    price: 24.99,
  },
  {
    id: "3",
    title: "Everest Bounce",
    producer: "SummitSounds",
    description: "Energetic bounce beat perfect for club bangers",
    audioUrl: "/beats/beat3.mp3",
    price: 34.99,
  },
  {
    id: "4",
    title: "Sherpa Flow",
    producer: "NepalBeats",
    description: "Melodic trap beat with flute samples and heavy 808s",
    audioUrl: "/beats/beat4.mp3",
    price: 19.99,
  },
  {
    id: "5",
    title: "Pokhara Sunset",
    producer: "LakeCity",
    description: "Chill lo-fi beat with guitar melodies and relaxed drums",
    audioUrl: "/beats/beat5.mp3",
    price: 22.99,
  },
  {
    id: "6",
    title: "Annapurna",
    producer: "MountainFlow",
    description: "Epic orchestral trap beat with cinematic elements",
    audioUrl: "/beats/beat6.mp3",
    price: 39.99,
  },
  {
    id: "7",
    title: "Thamel Streets",
    producer: "UrbanNepal",
    description: "Gritty boom bap beat with sampled street sounds",
    audioUrl: "/beats/beat7.mp3",
    price: 27.99,
  },
  {
    id: "8",
    title: "Mustang Valley",
    producer: "SummitSounds",
    description: "Ambient drill beat with spacious reverbs and punchy drums",
    audioUrl: "/beats/beat8.mp3",
    price: 29.99,
  },
]

export default function BeatGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {beats.map((beat) => (
        <BeatCard key={beat.id} {...beat} />
      ))}
    </div>
  )
}
