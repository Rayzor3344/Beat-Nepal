"use client"

import { useState, useRef } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Play, Pause, Download } from "lucide-react"
import { cn } from "@/lib/utils"

interface BeatCardProps {
  id: string
  title: string
  producer: string
  description: string
  audioUrl: string
  price: number
}

export default function BeatCard({ id, title, producer, description, audioUrl, price }: BeatCardProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const togglePlay = () => {
    if (!audioRef.current) return

    if (isPlaying) {
      audioRef.current.pause()
    } else {
      audioRef.current.play()
    }

    setIsPlaying(!isPlaying)
  }

  return (
    <Card className="overflow-hidden transition-all hover:shadow-md">
      <CardHeader className="p-4">
        <CardTitle className="line-clamp-1 text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="text-sm text-muted-foreground mb-2">Producer: {producer}</p>
        <p className="text-sm line-clamp-2 text-muted-foreground">{description}</p>
        <audio ref={audioRef} src={audioUrl} onEnded={() => setIsPlaying(false)} className="hidden" />
      </CardContent>
      <CardFooter className="flex justify-between items-center p-4 pt-0">
        <Button
          variant="outline"
          size="icon"
          className={cn(
            "rounded-full transition-colors",
            isPlaying && "bg-primary text-primary-foreground hover:bg-primary/90",
          )}
          onClick={togglePlay}
        >
          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </Button>
        <div className="flex items-center gap-2">
          <span className="font-medium">${price}</span>
          <Button variant="ghost" size="icon">
            <Download className="h-4 w-4" />
            <span className="sr-only">Download</span>
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
