"use client"

import type React from "react"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { Upload, Music } from "lucide-react"

const formSchema = z.object({
  title: z.string().min(2, {
    message: "Beat title must be at least 2 characters.",
  }),
  description: z.string().min(10, {
    message: "Description must be at least 10 characters.",
  }),
  price: z.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Price must be a positive number.",
  }),
  audioFile: z
    .instanceof(File, {
      message: "Please upload an audio file.",
    })
    .refine(
      (file) => file.size < 20 * 1024 * 1024, // 20MB
      {
        message: "File size must be less than 20MB.",
      },
    )
    .refine((file) => ["audio/mpeg", "audio/wav"].includes(file.type), {
      message: "File must be MP3 or WAV format.",
    }),
})

export default function UploadPage() {
  const [audioFile, setAudioFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      price: "",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsUploading(true)

    // Simulate upload
    setTimeout(() => {
      setIsUploading(false)
      toast({
        title: "Beat uploaded successfully!",
        description: "Your beat has been uploaded and is now pending review.",
      })
      form.reset()
      setAudioFile(null)
    }, 2000)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setAudioFile(file)
      form.setValue("audioFile", file)
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Upload Your Beat</h1>
        <p className="text-muted-foreground">Share your music with producers and artists around the world</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Beat Title</FormLabel>
                <FormControl>
                  <Input placeholder="Enter beat title" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Describe your beat (genre, mood, instruments, etc.)"
                    className="resize-none"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="price"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Price (USD)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="29.99" min="0.99" step="0.01" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="audioFile"
            render={({ field: { value, onChange, ...field } }) => (
              <FormItem>
                <FormLabel>Audio File</FormLabel>
                <FormControl>
                  <div className="grid w-full gap-2">
                    <div className="flex items-center justify-center w-full">
                      <label
                        htmlFor="audio-upload"
                        className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-md cursor-pointer bg-background hover:bg-accent/50 border-border"
                      >
                        <div className="flex flex-col items-center justify-center pt-5 pb-6 space-y-2">
                          {audioFile ? (
                            <>
                              <Music className="w-8 h-8 text-primary" />
                              <p className="text-sm text-muted-foreground">{audioFile.name}</p>
                              <p className="text-xs text-muted-foreground">
                                {(audioFile.size / (1024 * 1024)).toFixed(2)} MB
                              </p>
                            </>
                          ) : (
                            <>
                              <Upload className="w-8 h-8 text-muted-foreground" />
                              <p className="text-sm text-muted-foreground">Click to upload or drag and drop</p>
                              <p className="text-xs text-muted-foreground">MP3 or WAV (max. 20MB)</p>
                            </>
                          )}
                        </div>
                        <Input
                          id="audio-upload"
                          type="file"
                          accept="audio/mpeg,audio/wav"
                          className="hidden"
                          onChange={handleFileChange}
                          {...field}
                        />
                      </label>
                    </div>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button type="submit" className="w-full" disabled={isUploading}>
            {isUploading ? "Uploading..." : "Upload Beat"}
          </Button>
        </form>
      </Form>
    </div>
  )
}
