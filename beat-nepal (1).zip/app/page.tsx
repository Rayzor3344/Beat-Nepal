import BeatGrid from "@/components/beat-grid"

export default function Home() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Featured Beats</h1>
        <p className="text-muted-foreground">Discover premium beats from Nepal's top producers</p>
      </div>
      <BeatGrid />
    </div>
  )
}
